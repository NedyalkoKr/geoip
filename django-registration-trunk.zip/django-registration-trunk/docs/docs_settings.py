"""
Minimal Django settings file for documentation builds.

"""

INSTALLED_APPS = ["django_registration"]
